let getMSSV = document.getElementById("mssv");
let getName = document.getElementById("name");
let getEmail = document.getElementById("email");
let getGender = document.getElementsByName("gender");
let getSoThich = document.getElementsByName("so_thich");
let getSoThichKhac = document.getElementById("so_thich_khac");
let getQuocTich = document.getElementById("quoc_tich");
let getContent = document.getElementById("content");
let getDangKy = document.getElementById("dang_ky");
function addStyleError(element) {
  let formGroup = element.closest(".form-group");
  formGroup.classList.add("error");
}
function removeStyleError(element, type) {
  let formGroup;
  let event;
  if (type == "array") {
    formGroup = element[0].closest(".form-group");
    for (let i = 0; i < element.length; i++) {
      element[i].addEventListener("click", function () {
        formGroup.classList.remove("error");
      });
    }
  } else {
    formGroup = element.closest(".form-group");
    if (
      element.getAttribute("type") == "text" ||
      element.getAttribute("type") == "email" ||
      element.tagName == "TEXTAREA"
    ) {
      event = "keydown";
    } else if (element.tagName == "SELECT") {
      event = "change";
    }
    element.addEventListener(event, function () {
      formGroup.classList.remove("error");
    });
  }
}

function checkEmail() {
  var regx = /^([a-zA-Z0-9\.-]+)@([a-z0-9]+).([a-z]{2,8})(.[a-z]{2,8})?$/;
  return getEmail.value.match(regx) ? true : false;
}
function checkGender() {
  for (let i = 0; i < getGender.length; i++) {
    if (getGender[i].checked) {
      return true;
    }
  }
  return false;
}
for (let i = 0; i < getSoThich.length - 1; i++) {
  getSoThich[i].addEventListener("click", function () {
    getSoThichKhac.style.display = getSoThich[getSoThich.length - 2].checked
      ? "block"
      : "none";
  });
}
function checkSoThich() {
  let flag = false;
  let flag1 = false;
  for (let i = 0; i < getSoThich.length - 1; i++) {
    if (getSoThich[i].checked == true) {
      flag = true;
      break;
    }
  }
  if (
    getSoThich[getSoThich.length - 2].checked &&
    getSoThich[getSoThich.length - 1].value == ""
  ) {
    flag1 = false;
    addStyleError(getSoThich[getSoThich.length - 1]);
    removeStyleError(getSoThich[getSoThich.length - 1]);
  }
  if (flag) {
    removeStyleError(getSoThich[0]);
  } else {
    addStyleError(getSoThich[0]);
  }

  return flag;
}
getDangKy.addEventListener("click", function (e) {
  e.preventDefault();
  let textError = "";
  if (getMSSV.value == "") {
    textError += "Vui lòng nhập mã số sinh viên! \n";
    addStyleError(getMSSV);
    removeStyleError(getMSSV);
  }
  if (getName.value == "") {
    textError += "Vui lòng nhập tên!\n";
    addStyleError(getName);
    removeStyleError(getName);
  }
  if (getEmail.value == "") {
    textError += "Vui lòng nhập Email!\n";
    addStyleError(getEmail);
    removeStyleError(getEmail);
  } else if (!checkEmail()) {
    textError += "Định dạng Email chưa đúng!\n";
    addStyleError(getEmail);
    removeStyleError(getEmail);
  }
  if (!checkGender()) {
    textError += "Vui lòng chọn giới tính !\n";
    addStyleError(getGender[0]);
    removeStyleError(getGender, "array");
  }
  if (!checkSoThich()) {
    textError += "Vui lòng chọn sở thích!\n";
    removeStyleError(getSoThich, "array");
  }
  if (getQuocTich.value == "") {
    textError += "Vui lòng chọn quốc tịch!\n";
    addStyleError(getQuocTich);
    removeStyleError(getQuocTich);
  }
  if (getContent.value == "") {
    textError += "Vui lòng nhập nội dung!\n";
    addStyleError(getContent);
    removeStyleError(getContent);
  } else if (getContent.value.length < 200) {
    textError += "Nội dung phải lớn hơn 200!\n";
    addStyleError(getContent);
    removeStyleError(getContent);
  }
  if (textError == "") {
    alert("Chúc mừng bạn đã nhập đúng");
  } else {
    alert(textError);
  }
});
